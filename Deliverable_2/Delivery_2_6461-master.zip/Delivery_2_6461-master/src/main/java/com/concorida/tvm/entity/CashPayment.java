package com.concorida.tvm.entity;

public class CashPayment extends Payment{
}
