package com.concorida.tvm.dao.impl;

import com.concorida.tvm.dao.MetroCardDao;
import com.concorida.tvm.entity.MetroCard;

public class MetroCardDaoImpl implements MetroCardDao {
    @Override
    public MetroCard getMetroCardInfoById() {
        return null;
    }
}
