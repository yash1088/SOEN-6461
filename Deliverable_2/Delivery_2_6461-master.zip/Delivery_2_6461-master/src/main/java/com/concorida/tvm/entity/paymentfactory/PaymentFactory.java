package com.concorida.tvm.entity.paymentfactory;

import com.concorida.tvm.entity.Payment;

public interface PaymentFactory {
    Payment createPayment();
}
