package com.concorida.tvm.dao;

import com.concorida.tvm.entity.MetroCard;

public interface MetroCardDao {
    MetroCard getMetroCardInfoById();
}
